-- Meal Coupon Exchange: run once in Supabase > SQL Editor.
create table profiles(
 id uuid primary key references auth.users on delete cascade,
 name text not null, upi text, qr text,
 completed int not null default 0, strikes int not null default 0,
 banned boolean not null default false, cooldown_until timestamptz,
 created_at timestamptz not null default now());
create table orders(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references profiles(id),
 side text not null check (side in ('buy','sell')),
 price int not null check (price between 1 and 9999),
 qty int not null check (qty between 1 and 50),
 remaining int not null,
 status text not null default 'open' check (status in ('open','matched','cancelled','expired')),
 slot text not null check (slot in ('lunch','dinner')),
 session_date date not null,
 created_at timestamptz not null default now());
create index on orders(session_date,slot,status);
create table order_codes(order_id uuid primary key references orders on delete cascade, user_id uuid not null, codes text[] not null);
create table trades(
 id uuid primary key default gen_random_uuid(),
 buy_order uuid references orders, sell_order uuid references orders,
 buyer_id uuid not null references profiles(id), seller_id uuid not null references profiles(id),
 price int not null, qty int not null, slot text not null, session_date date not null,
 status text not null default 'pending' check (status in ('pending','paid','done','expired','disputed','flagged')),
 pay_ref text, created_at timestamptz not null default now(),
 expires_at timestamptz not null default now()+interval '10 minutes',
 paid_at timestamptz, seller_deadline timestamptz);
create table trade_codes(trade_id uuid primary key references trades on delete cascade, buyer_id uuid not null, codes text[] not null);
create view market_trades as select price,qty,slot,session_date,created_at from trades where status<>'expired';

-- Access: clients can only read; every write goes through the functions below.
alter table profiles enable row level security; alter table orders enable row level security;
alter table order_codes enable row level security; alter table trades enable row level security;
alter table trade_codes enable row level security;
revoke all on profiles,orders,order_codes,trades,trade_codes,market_trades from anon,authenticated;
grant select on profiles,orders,order_codes,trades,trade_codes,market_trades to authenticated;
grant insert (id,name,upi,qr), update (name,upi,qr) on profiles to authenticated;
create policy p_sel on profiles for select to authenticated using (id=auth.uid() or exists(select 1 from trades t where (t.buyer_id=auth.uid() and t.seller_id=profiles.id) or (t.seller_id=auth.uid() and t.buyer_id=profiles.id)));
create policy p_ins on profiles for insert to authenticated with check (id=auth.uid());
create policy p_upd on profiles for update to authenticated using (id=auth.uid());
create policy o_sel on orders for select to authenticated using (true);
create policy oc_sel on order_codes for select to authenticated using (user_id=auth.uid());
create policy t_sel on trades for select to authenticated using (buyer_id=auth.uid() or seller_id=auth.uid());
create policy tc_sel on trade_codes for select to authenticated using (buyer_id=auth.uid() and exists(select 1 from trades t where t.id=trade_id and t.status in ('done','flagged')));
alter publication supabase_realtime add table orders, trades;

-- Server clock (India time) decides sessions and deadlines.
create function ist_date() returns date language sql stable as $$ select (now() at time zone 'Asia/Kolkata')::date $$;
create function slot_open(s text) returns boolean language sql stable as $$
 select case s when 'lunch' then (now() at time zone 'Asia/Kolkata')::time >= '12:00' and (now() at time zone 'Asia/Kolkata')::time < '14:30'
 else (now() at time zone 'Asia/Kolkata')::time >= '18:00' end $$;

-- Atomic matching. Codes move to trade_codes at match time, so they can't be sold twice.
create function match_order(oid uuid) returns int language plpgsql security definer set search_path=public as $$
declare o orders; c orders; q int; n int:=0; tid uuid; sid uuid; sc text[];
begin
 select * into o from orders where id=oid for update;
 while o.remaining>0 loop
  select * into c from orders where status='open' and slot=o.slot and session_date=o.session_date and user_id<>o.user_id
   and side=(case when o.side='sell' then 'buy' else 'sell' end)
   and (case when o.side='sell' then price>=o.price else price<=o.price end)
   order by (case when o.side='sell' then -price else price end), created_at limit 1 for update skip locked;
  exit when not found;
  q:=least(o.remaining,c.remaining);
  sid:=case when o.side='sell' then o.id else c.id end;
  insert into trades(buy_order,sell_order,buyer_id,seller_id,price,qty,slot,session_date) values(
   case when o.side='buy' then o.id else c.id end, sid,
   case when o.side='buy' then o.user_id else c.user_id end,
   case when o.side='sell' then o.user_id else c.user_id end, c.price,q,o.slot,o.session_date) returning id into tid;
  select codes[1:q] into sc from order_codes where order_id=sid for update;
  update order_codes set codes=codes[q+1:cardinality(codes)] where order_id=sid;
  insert into trade_codes select id,buyer_id,sc from trades where id=tid;
  update orders set remaining=remaining-q, status=case when remaining-q=0 then 'matched' else 'open' end where id in (o.id,c.id);
  o.remaining:=o.remaining-q; n:=n+1;
 end loop;
 return n;
end $$;

create function place_order(p_side text,p_price int,p_qty int,p_slot text,p_codes text[] default '{}')
returns int language plpgsql security definer set search_path=public as $$
declare me uuid:=auth.uid(); pr profiles; oid uuid;
begin
 select * into pr from profiles where id=me;
 if pr.id is null then raise exception 'Create your profile first'; end if;
 if pr.banned then raise exception 'Your account is blocked after repeated invalid-code reports'; end if;
 if pr.cooldown_until>now() then raise exception 'Paused until % after missed payments', to_char(pr.cooldown_until at time zone 'Asia/Kolkata','HH24:MI'); end if;
 if p_slot not in ('lunch','dinner') or not slot_open(p_slot) then raise exception 'This session is closed'; end if;
 if p_side not in ('buy','sell') or p_price not between 1 and 9999 or p_qty not between 1 and 50 then raise exception 'Invalid order'; end if;
 if (select count(*) from orders where user_id=me and status='open')>=10 then raise exception 'Too many open orders'; end if;
 if p_side='sell' then
  if coalesce(cardinality(p_codes),0)<>p_qty or (select count(distinct x) from unnest(p_codes) x)<>p_qty
   or exists(select 1 from unnest(p_codes) x where x !~ '^\d{6}$') then raise exception 'Enter % different 6-digit codes', p_qty; end if;
  if exists(select 1 from order_codes oc join orders o on o.id=oc.order_id where o.status in ('open','matched') and oc.codes && p_codes)
   or exists(select 1 from trade_codes where codes && p_codes) then raise exception 'One or more codes are already listed or sold'; end if;
  update order_codes oc set codes=(select coalesce(array_agg(x),'{}') from unnest(oc.codes) x where x<>all(p_codes))
   from orders o where o.id=oc.order_id and o.status in ('cancelled','expired') and oc.user_id=me and oc.codes && p_codes;
 end if;
 insert into orders(user_id,side,price,qty,remaining,slot,session_date) values(me,p_side,p_price,p_qty,p_qty,p_slot,ist_date()) returning id into oid;
 if p_side='sell' then insert into order_codes values(oid,me,p_codes); end if;
 return match_order(oid);
end $$;

create function cancel_order(p_order uuid) returns void language sql security definer set search_path=public as $$
 update orders set status='cancelled' where id=p_order and user_id=auth.uid() and status='open' $$;

create function mark_paid(p_trade uuid,p_ref text) returns void language plpgsql security definer set search_path=public as $$
begin
 update trades set status='paid',pay_ref=trim(p_ref),paid_at=now(),seller_deadline=now()+interval '30 minutes'
  where id=p_trade and buyer_id=auth.uid() and status='pending' and expires_at>now() and length(trim(p_ref))>=4;
 if not found then raise exception 'Cannot mark as paid: the 10 minutes ended or the reference is under 4 characters'; end if;
end $$;

create function confirm_received(p_trade uuid) returns void language plpgsql security definer set search_path=public as $$
declare t trades;
begin
 select * into t from trades where id=p_trade and seller_id=auth.uid() and status in ('paid','disputed') for update;
 if not found then raise exception 'This deal is not waiting for your confirmation'; end if;
 update trades set status='done' where id=t.id;
 update profiles set completed=completed+1 where id in (t.buyer_id,t.seller_id);
end $$;

create function dispute(p_trade uuid) returns void language sql security definer set search_path=public as $$
 update trades set status='disputed' where id=p_trade and status='paid' and auth.uid() in (buyer_id,seller_id) $$;

-- Two reports from two different buyers block a seller. Admins can undo it (see README).
create function report_code(p_trade uuid) returns void language plpgsql security definer set search_path=public as $$
declare sid uuid;
begin
 update trades set status='flagged' where id=p_trade and buyer_id=auth.uid() and status='done' returning seller_id into sid;
 if not found then raise exception 'Cannot report this deal'; end if;
 if (select count(distinct buyer_id) from trades where seller_id=sid and status='flagged')>=2 then update profiles set banned=true where id=sid; end if;
end $$;

-- Run by every client every 15s (and optionally by pg_cron). Anyone can trigger it; it only applies deadlines.
create function tick() returns void language plpgsql security definer set search_path=public as $$
declare t trades;
begin
 for t in select * from trades where status='pending' and expires_at<now() for update skip locked loop
  update trades set status='expired' where id=t.id;
  update order_codes oc set codes=oc.codes||tc.codes from trade_codes tc where tc.trade_id=t.id and oc.order_id=t.sell_order;
  delete from trade_codes where trade_id=t.id;
  update orders set remaining=remaining+t.qty,status='open' where id=t.sell_order and status in ('open','matched') and session_date=ist_date();
  update profiles set strikes=strikes+1,cooldown_until=case when strikes+1>=2 then now()+interval '30 minutes' else cooldown_until end where id=t.buyer_id;
  perform match_order(t.sell_order) from orders where id=t.sell_order and status='open';
 end loop;
 update trades set status='disputed' where status='paid' and seller_deadline<now();
 update orders set status='expired' where status in ('open','matched') and session_date<ist_date();
end $$;

revoke execute on all functions in schema public from public,anon,authenticated;
grant execute on function place_order,cancel_order,mark_paid,confirm_received,dispute,report_code,tick to authenticated;
