// Supabase > Project Settings > API. The anon key is public by design; the database rules protect the data.
export const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';
