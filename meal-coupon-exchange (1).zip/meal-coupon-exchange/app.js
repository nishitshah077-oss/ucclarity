import {createClient} from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';
import {SUPABASE_URL,SUPABASE_ANON_KEY} from './config.js';
const sb=createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SL={lunch:{h:'12:00 PM–2:30 PM',a:720,b:870},dinner:{h:'6:00 PM–12:00 AM',a:1080,b:1440}};
let me,profile,slot='lunch',side='sell',orders=[],trades=[],mt=[],unsold=[],cps={},codes={},prev={},primed=false,started=false,qr='',editing=false,t0;
const ist=()=>{const p=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).formatToParts(new Date()).map(x=>[x.type,x.value]));return{d:`${p.year}-${p.month}-${p.day}`,m:(+p.hour%24)*60+ +p.minute}};
const isOpen=s=>{const m=ist().m;return m>=SL[s].a&&m<SL[s].b};
const show=v=>['auth','profile','app'].forEach(k=>$(k).hidden=k!==v);
const gate=t=>{$('gate').hidden=!t;$('gate').textContent=t||''};
const rpc=async(f,a)=>{const {data,error}=await sb.rpc(f,a);if(error)throw error;return data};
const askNotify=()=>{if('Notification' in window&&Notification.permission==='default')Notification.requestPermission()};

if(SUPABASE_URL.includes('YOUR-PROJECT'))gate('Add your Supabase URL and anon key in config.js (see README).');
else boot();
sb.auth.onAuthStateChange((e)=>{if(e==='SIGNED_OUT')location.reload()});

async function boot(){
 const {data:{session}}=await sb.auth.getSession();
 if(!session)return show('auth');
 me=session.user.id;
 const {data}=await sb.from('profiles').select('*').eq('id',me).maybeSingle();
 profile=data;
 if(!profile||editing)return show('profile');
 show('app');await load();
 if(!started){started=true;
  sb.channel('live').on('postgres_changes',{event:'*',schema:'public',table:'orders'},kick).on('postgres_changes',{event:'*',schema:'public',table:'trades'},kick).subscribe();
  setInterval(async()=>{try{await rpc('tick')}catch(e){}load()},15000);
  addEventListener('focus',()=>document.title='Meal Coupon Exchange');
 }
}
const kick=()=>{clearTimeout(t0);t0=setTimeout(load,300)};

// ---- auth and profile
async function authGo(up){
 const c={email:$('em').value.trim(),password:$('pw').value};
 const {data,error}=up?await sb.auth.signUp(c):await sb.auth.signInWithPassword(c);
 if(error)return $('am').textContent=error.message;
 if(!data.session)return $('am').textContent='Check your email to confirm your account, then sign in.';
 askNotify();boot();
}
$('in').onclick=()=>authGo(false);$('up').onclick=()=>authGo(true);
$('out').onclick=()=>sb.auth.signOut();
$('edit').onclick=()=>{editing=true;$('pName').value=profile.name||'';$('pUpi').value=profile.upi||'';qr=profile.qr||'';prevQr();show('profile')};
const prevQr=()=>{$('pPrev').hidden=!qr;if(qr)$('pPrev').src=qr};
$('pQr').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const s=Math.min(1,360/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*s);c.height=Math.round(im.height*s);c.getContext('2d').drawImage(im,0,0,c.width,c.height);qr=c.toDataURL('image/jpeg',.85);prevQr()};im.onerror=()=>$('pMsg').textContent='Could not read that image.';im.src=r.result};r.readAsDataURL(f)};
$('pSave').onclick=async()=>{
 const name=$('pName').value.trim(),upi=$('pUpi').value.trim();
 if(!name||(!upi&&!qr))return $('pMsg').textContent='Add your name and a UPI ID or QR image.';
 const q=profile?sb.from('profiles').update({name,upi,qr}).eq('id',me):sb.from('profiles').insert({id:me,name,upi,qr});
 const {error}=await q;if(error)return $('pMsg').textContent=error.message;
 editing=false;$('pMsg').textContent='';askNotify();boot();
};

// ---- data
async function load(){
 const [o,t,m,u]=await Promise.all([
  sb.from('orders').select('*').eq('session_date',ist().d).eq('status','open').limit(500),
  sb.from('trades').select('*').order('created_at',{ascending:false}).limit(100),
  sb.from('market_trades').select('*').order('created_at',{ascending:false}).limit(300),
  sb.from('order_codes').select('codes,orders!inner(status,price,slot)').in('orders.status',['cancelled','expired'])]);
 orders=o.data||[];trades=t.data||[];mt=m.data||[];unsold=(u.data||[]).filter(x=>x.codes?.length);
 const ids=[...new Set(trades.map(x=>x.buyer_id===me?x.seller_id:x.buyer_id))].filter(i=>!cps[i]);
 if(ids.length){const {data}=await sb.from('profiles').select('id,name,upi,qr,completed').in('id',ids);(data||[]).forEach(p=>cps[p.id]=p)}
 for(const x of trades)if(x.buyer_id===me&&['done','flagged'].includes(x.status)&&!codes[x.id]){const {data}=await sb.from('trade_codes').select('codes').eq('trade_id',x.id).maybeSingle();if(data)codes[x.id]=data.codes}
 notify();render();
}
function notify(){
 trades.forEach(t=>{const old=prev[t.id],buy=t.buyer_id===me;prev[t.id]=t.status;if(!primed||old===t.status)return;
  const m=old===undefined?`Order matched: ${t.qty} coupon(s) at ₹${t.price}`:t.status==='paid'&&!buy?'The buyer has paid. Check UPI and confirm.':t.status==='done'&&buy?'Your coupon codes are ready':t.status==='disputed'?'A deal moved to dispute':t.status==='expired'?'A deal expired':null;
  if(m){document.title='● '+m;navigator.vibrate?.(200);if('Notification' in window&&Notification.permission==='granted')new Notification('Meal Coupon Exchange',{body:m})}});
 primed=true;
}

// ---- view
const lv=sd=>{const m={};orders.filter(o=>o.side===sd&&o.slot===slot).forEach(o=>m[o.price]=(m[o.price]||0)+o.remaining);return Object.entries(m).map(([p,n])=>[+p,n]).sort((a,b)=>sd==='sell'?a[0]-b[0]:b[0]-a[0])};
const refPrice=()=>{const m=mt.filter(t=>t.slot===slot);return (m.find(t=>t.session_date===ist().d)||m[0])?.price};
const tm=t=>new Date(t.created_at).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
function chart(){
 const T=mt.filter(t=>t.slot===slot&&t.session_date===ist().d).reverse();
 if(!T.length)return '<p class="mu">The chart starts with the first trade of this session.</p>';
 const W=600,H=160,ps=T.map(t=>t.price),lo=Math.min(...ps),hi=Math.max(...ps),pad=Math.max(1,(hi-lo)*.2),mn=lo-pad,mx=hi+pad,X=i=>40+(W-50)*i/Math.max(1,T.length-1),Y=p=>H-20-(H-40)*(p-mn)/(mx-mn);
 return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Price chart"><polyline points="${ps.map((p,i)=>X(i)+','+Y(p)).join(' ')}" fill="none" stroke="var(--ac)" stroke-width="2"/>${ps.map((p,i)=>`<circle cx="${X(i)}" cy="${Y(p)}" r="4" fill="var(--ac)"><title>₹${p} · ${T[i].qty} coupon(s) · ${tm(T[i])}</title></circle>`).join('')}<g font-size="11" fill="var(--mu)"><text x="2" y="${Y(hi)+4}">₹${hi}</text><text x="2" y="${Y(lo)+4}">₹${lo}</text><text x="40" y="${H-3}">${tm(T[0])}</text><text x="${W-10}" y="${H-3}" text-anchor="end">${tm(T.at(-1))}</text></g></svg>`;
}
function render(){
 const open=isOpen(slot),A=lv('sell'),B=lv('buy'),last=mt.find(t=>t.slot===slot&&t.session_date===ist().d),rp=refPrice();
 $('who').textContent=profile.name;
 $('lunch').className=slot==='lunch'?'on':'';$('dinner').className=slot==='dinner'?'on':'';
 $('st').textContent=(slot==='lunch'?'Lunch':'Dinner')+' coupons · '+(open?'trading open':'trading closed');
 $('sNote').textContent=open?'':'Opens '+SL[slot].h;$('go').disabled=!open;
 $('ask').textContent=A.length?'₹'+A[0][0]:'–';$('bid').textContent=B.length?'₹'+B[0][0]:'–';
 $('last').textContent=last?'₹'+last.price:rp?'₹'+rp+' (previous)':'–';
 $('refNote').textContent=rp?'Reference price ₹'+rp:'';
 $('chart').innerHTML=chart();
 const col=(L,cls,sd,title,verb)=>`<div class="${cls}"><b>${title}</b><div class="mu">${verb}</div>${[...Array(5)].map((_,i)=>L[i]?`<button class="lvl ${cls}" data-a="lvl" data-p="${L[i][0]}" data-s="${sd}"><b>₹${L[i][0]}</b><span>${L[i][1]} coupon${L[i][1]>1?'s':''}</span></button>`:'<div class="lvl mu"><span>–</span></div>').join('')}</div>`;
 $('depth').innerHTML=col(B,'bid','sell','Buyers','Tap to sell at this price')+col(A,'ask','buy','Sellers','Tap to buy at this price');
 const mine=orders.filter(o=>o.user_id===me&&o.slot===slot);
 $('mine').innerHTML=mine.length?mine.map(o=>`<div class="bar deal"><span><b class="${o.side==='sell'?'s':'b'}">${o.side==='sell'?'Selling':'Buying'} ${o.remaining}</b> at ₹${o.price}</span><button data-a="cancel" data-id="${o.id}">Cancel</button></div>`).join(''):'<p class="mu">Nothing open.</p>';
 $('unsoldC').hidden=!unsold.length;
 $('unsold').innerHTML=unsold.map((u,i)=>`<div class="bar deal"><span>${u.codes.length} unsold ${u.orders.slot} coupon(s) · listed at ₹${u.orders.price}</span><button data-a="relist" data-i="${i}">List again</button></div>`).join('');
 const keep={};document.querySelectorAll('[id^=ref-]').forEach(i=>keep[i.id]=i.value);
 const act=trades.filter(t=>['pending','paid','disputed'].includes(t.status)),his=trades.filter(t=>!act.includes(t));
 $('deals').innerHTML=act.length?act.map(deal).join(''):'<p class="mu">No active deals.</p>';
 $('hist').innerHTML=his.map(deal).join('')||'<p class="mu">No past deals.</p>';$('hc').textContent=his.length;
 Object.entries(keep).forEach(([k,v])=>{if($(k))$(k).value=v});
}
function deal(t){
 const buy=t.buyer_id===me,cp=cps[buy?t.seller_id:t.buyer_id]||{},amt=t.price*t.qty,tag=t.id.slice(0,4).toUpperCase(),left=Math.max(0,Math.ceil((new Date(t.expires_at)-Date.now())/1000));
 let h=`<div class="deal"><b>${buy?'Buying':'Selling'} ${t.qty} coupon${t.qty>1?'s':''} at ₹${t.price}</b> <span class="tag">#${tag}</span> <span class="tag">${t.status}</span><div class="mu">${buy?'Seller':'Buyer'}: ${esc(cp.name||'…')} · ${cp.completed||0} completed deals · Total ₹${amt}</div>`;
 if(buy&&t.status==='pending'){
  h+=`<p class="mu">Pay within ${Math.floor(left/60)}:${String(left%60).padStart(2,'0')} or the deal expires.</p>`;
  if(cp.upi)h+=`<p><a class="btn" href="upi://pay?pa=${encodeURIComponent(cp.upi)}&pn=${encodeURIComponent(cp.name||'')}&am=${amt}&cu=INR&tn=${encodeURIComponent('Coupons #'+tag)}">Pay ₹${amt} in UPI app</a> <button data-a="copy" data-v="${esc(cp.upi)}">Copy UPI ID: ${esc(cp.upi)}</button></p>`;
  if(String(cp.qr||'').startsWith('data:image/'))h+=`<img class="qr" src="${cp.qr}" alt="Seller UPI QR">`;
  h+=`<label for="ref-${t.id}">UPI reference (last 4+ characters of the transaction ID)</label><input id="ref-${t.id}" maxlength="30"><button class="pri" data-a="paid" data-id="${t.id}">I’ve paid ₹${amt}</button>`;
 }
 if(buy&&t.status==='paid')h+=`<p class="mu">Waiting for the seller to confirm. If nothing happens in 30 minutes, the deal moves to dispute.</p><button data-a="dispute" data-id="${t.id}">Report a problem</button>`;
 if(!buy&&t.status==='pending')h+=`<p class="mu">Waiting for the buyer to pay.</p>`;
 if(!buy&&(t.status==='paid'||t.status==='disputed'))h+=`<p>Buyer’s UPI reference: <b>${esc(t.pay_ref||'–')}</b></p><button class="pri" data-a="recv" data-id="${t.id}" data-amt="${amt}">I received ₹${amt}. Release the codes</button>${t.status==='paid'?`<p><button data-a="dispute" data-id="${t.id}">Payment not received</button></p>`:''}`;
 if(t.status==='disputed')h+=`<p class="mu">This deal is in dispute and will be reviewed.</p>`;
 if(t.status==='expired')h+=`<p class="mu">${buy?'Payment was not confirmed in 10 minutes.':'The buyer did not pay in time. Your coupons are back on the market.'}</p>`;
 if(buy&&codes[t.id])h+=codes[t.id].map(c=>`<div class="code"><span>${esc(c)}</span><button data-a="copy" data-v="${esc(c)}">Copy</button></div>`).join('')+(t.status==='done'?`<button data-a="report" data-id="${t.id}">A code didn’t work</button>`:'<p class="mu">Reported as invalid.</p>');
 return h+'</div>';
}

// ---- actions
function setSide(s){side=s;$('bSell').className=s==='sell'?'on':'';$('bBuy').className=s==='buy'?'on':'';$('sellF').hidden=s!=='sell';$('go').textContent='Place '+s+' order'}
setSide('sell');
$('go').onclick=async()=>{
 const price=+$('price').value,qty=+$('qty').value,msg=$('msg'),rp=refPrice();msg.textContent='';
 if(!(price>=1&&qty>=1))return msg.textContent='Enter a quantity and a price.';
 if(rp&&Math.abs(price-rp)/rp>.3&&!confirm(`₹${price} is more than 30% away from the reference price ₹${rp}. Continue?`))return;
 $('go').disabled=true;
 try{const n=await rpc('place_order',{p_side:side,p_price:price,p_qty:qty,p_slot:slot,p_codes:side==='sell'?$('codes').value.split(/[\s,;]+/).filter(Boolean):[]});
  msg.style.color='var(--ac)';msg.textContent=n?`Matched in ${n} deal${n>1?'s':''}. See My deals.`:'Order placed. Waiting for a match.';$('codes').value='';await load();
 }catch(e){msg.style.color='var(--se)';msg.textContent=e.message}
 render();
};
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,id=b.dataset.id;
 try{
  if(a==='slot'){slot=b.dataset.s;return render()}
  if(a==='side')return setSide(b.dataset.s);
  if(a==='lvl'){setSide(b.dataset.s);$('price').value=b.dataset.p;return $('price').focus()}
  if(a==='best'){const L=lv(side==='buy'?'sell':'buy');if(L.length)$('price').value=L[0][0];return}
  if(a==='copy'){await navigator.clipboard.writeText(b.dataset.v);b.textContent='Copied';return}
  if(a==='relist'){const u=unsold[+b.dataset.i];slot=u.orders.slot;setSide('sell');$('qty').value=u.codes.length;$('price').value=u.orders.price;$('codes').value=u.codes.join('\n');render();return $('go').scrollIntoView()}
  if(a==='cancel')await rpc('cancel_order',{p_order:id});
  if(a==='paid')await rpc('mark_paid',{p_trade:id,p_ref:$('ref-'+id).value});
  if(a==='recv'){if(!confirm(`Confirm you received ₹${b.dataset.amt}? The codes are released to the buyer and this cannot be undone.`))return;await rpc('confirm_received',{p_trade:id})}
  if(a==='dispute')await rpc('dispute',{p_trade:id});
  if(a==='report'){if(!confirm('Report this code as invalid? Two reports from different buyers block the seller.'))return;await rpc('report_code',{p_trade:id})}
  await load();
 }catch(err){alert(err.message)}
});
