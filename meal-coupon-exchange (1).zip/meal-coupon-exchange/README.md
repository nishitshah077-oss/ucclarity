# Meal Coupon Exchange

Static site (no build step) + Supabase (login, database, realtime). Matching, deadlines, code release and reports run in the database, so they can't be bypassed from the browser.

## Set up
1. **Supabase**: create a project. Open *SQL Editor*, paste `supabase/schema.sql`, run it.
2. *Authentication > Providers > Email*: for quick testing turn off "Confirm email". To limit sign-ups to a community, keep it on and add a domain check later.
3. *Project Settings > API*: copy the Project URL and `anon` key into `config.js`. The anon key is safe to publish; row-level security protects the data.
4. **GitHub**: `git init && git add . && git commit -m "Meal Coupon Exchange" `, then push to a new repo.
5. **Vercel**: *Add New > Project*, import the repo. Framework preset: **Other**. No build command, no output directory. Deploy.
6. Supabase *Authentication > URL Configuration*: set Site URL to your Vercel URL.

Local preview: `npm run dev`.

## Rules built in (server side)
- India time decides sessions: lunch 12:00–2:30 PM, dinner 6:00 PM–midnight.
- Buyer has 10 minutes to pay. A no-show adds a strike; two strikes pause that user for 30 minutes. The seller's coupons return to the book.
- Buyer must enter a UPI reference. Seller has 30 minutes to confirm, then the deal moves to **disputed**.
- Codes must be 6 digits, unique in the order, and not already listed or sold. Codes are stored privately and moved out of the order at match time.
- Two reports from two different buyers block a seller.

## Admin (Supabase Table Editor / SQL)
- Disputes: `select * from trades where status='disputed';` then set `status` to `done` or `expired`.
- Unblock: `update profiles set banned=false where id='…';`
- Optional: run `tick()` every minute with pg_cron: `select cron.schedule('tick','* * * * *','select public.tick()');`

## Not included yet
Candlestick chart and demo mode from v3, "mark redeemed", and all-or-nothing orders.
